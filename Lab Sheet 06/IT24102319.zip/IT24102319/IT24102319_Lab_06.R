setwd("C:\\Users\\Jana\\Desktop\\IT24102319")

#Q1-i
#Binomial distribution

#Q1-ii
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)

#Q2-i
#Number of customer calls received in per hour

#Q2-ii
#Poisson distribution 

#Q2-iii
dpois(15, 12)